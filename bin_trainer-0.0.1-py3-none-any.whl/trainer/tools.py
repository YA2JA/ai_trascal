import trainer.train as train

INPUT_DIR  = r'./input'
OUTPUT_DIR = r'./output'
CLASS_LIST = ['0', '1', '2']

class Label():
    def run(self):
        import trainer.lebel_app as lebel_app

        lebel_app.INPUT_DIR = INPUT_DIR
        lebel_app.OUTPUT_DIR = OUTPUT_DIR
        lebel_app.CLASS_LIST = CLASS_LIST
        lebel_app.main()

class Train():
    def run(self, **config):
        confFile = config.get('data') or "./conf-train.yaml"
        epochs = config.get('epochs') or 600
        imgsz = config.get('imgsz') or 360
        train.run(data=confFile, imgsz=imgsz, batch=5, epochs=epochs, noplots=True, weights='./model.pt', verbose=False)
