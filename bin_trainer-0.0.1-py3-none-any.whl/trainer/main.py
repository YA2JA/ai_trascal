import trainer.train as train; 

class Train():
    def run(self, **config):
        confFile = config.get('data') or "./conf-train.yaml"
        epochs = config.get('epochs') or 600
        imgsz = config.get('imgsz') or 360
        train.run(data=confFile, imgsz=imgsz, batch=5, epochs=epochs, noplots=True, weights='./model.pt', verbose=False)

if __name__ == '__main__':
    model = Train()
    model.run()